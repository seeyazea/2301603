from flask import Flask, request, render_template, jsonify
import re
import joblib
from difflib import SequenceMatcher

app = Flask(__name__)

model = joblib.load('model/model.pkl')
vectorizer = joblib.load('model/tfidf_vectorizer.pkl')

def load_verified_articles():
    with open('verified_data/verified_articles.txt', encoding='utf-8') as f:
        return f.readlines()

verified_articles = load_verified_articles()

def compute_similarity(text1, articles):
     return max(SequenceMatcher(None, text1, article.strip()).ratio() for article in articles)

def happyface_score(percent):
    if percent >= 0.9:
        return (1, "😊 매우 신뢰도 높음")
    elif percent >= 0.75:
        return (2, "🙂 신뢰도 높음")
    elif percent >= 0.5:
        return (3, "😐 중간")
    elif percent >= 0.3:
        return (4, "😕 신뢰 낮음")
    else:
        return (5, "😡 가짜 뉴스 가능성 높음")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check', methods=['POST'])
def check_news():
    text = request.form['news_text']
    cleaned = re.sub(r'[^가-힣a-zA-Z0-9\s]', '', text)
    vector = vectorizer.transform([cleaned])
    prediction = model.predict(vector)[0]

    similarity = compute_similarity(cleaned, verified_articles)
    percent = round(similarity * 100, 2)
    score, level = happyface_score(similarity)

    result = {
        "ai": "🤖 happyface",
        "prediction": "진짜 뉴스" if prediction == 0 else "가짜 뉴스 가능성",
        "similarity": percent,
        "score": score,
        "level": level
    }
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
