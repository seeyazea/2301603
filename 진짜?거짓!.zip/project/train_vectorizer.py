import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib

df = pd.read_csv("news.csv") 
df = df.dropna()
X = df['text']
y = df['label'].map({'FAKE': 1, 'REAL': 0})  

vectorizer = TfidfVectorizer(stop_words='english', max_df=0.7)
X_vec = vectorizer.fit_transform(X)

model = PassiveAggressiveClassifier()
model.fit(X_vec, y)

joblib.dump(vectorizer, 'model/tfidf_vectorizer.pkl')
joblib.dump(model, 'model/model.pkl')



